unsigned char read8271(unsigned short addr);
void write8271(unsigned short addr, unsigned char val);
FILE *f8271;
int disctime, discint;
